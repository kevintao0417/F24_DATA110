# ifood-data-business-analyst-test
## last update 19/02/2020
<br><br>
This case is used for hiring Data Analysts for the iFood Brain team. Instructions are in the pdf file. <br><br>

If you are interested in joining our team, or getting to know more about iFood and our team, feel free to send an e-mail to "ifoodbrain_hiring@ifood.com.br".<br><br>
